package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.RatingDAO;
import com.example.demo.domain.Rating;
import com.example.demo.domain.Paper;

@Component
public class RatingService{
	
	@Autowired
	RatingDAO ratingDAO;
	public List<Rating> getRatingList(){
		List<Rating> ratingList = new ArrayList<Rating>();
		ratingList = ratingDAO.getRatingList();
		return ratingList;
	}
	public List<Rating> getRatingListForPaper(Paper paper){
		List<Rating> ratingList = new ArrayList<Rating>();
		ratingList = ratingDAO.getRatingListForPaper(paper);
		return ratingList;
	}
	public void uploadRating(Rating rating){
		ratingDAO.uploadRating(rating);
	}
}
