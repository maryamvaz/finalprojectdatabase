package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.ParticipatorDAO;
import com.example.demo.domain.Participator;

@Component
public class ParticipatorService{
	
	@Autowired
	ParticipatorDAO participatorDAO;
	public void registerParticipator(Participator participator){
		participatorDAO.registerParticipator(participator);
		registerParticipatorRole(participator);
	}
	private void registerParticipatorRole(Participator participator){
		if (participator.getRole().equals("Author"))
			participatorDAO.registerAuthor(participator);
		else if (participator.getRole().equals("Reviewer")){
			participatorDAO.registerReviewer(participator);
		}
		else if (participator.getRole().equals("Both")){
			participatorDAO.registerReviewer(participator);
			participatorDAO.registerAuthor(participator);
		}
	}
	public Participator getParticipator(Participator participator){
		List<Participator> participatorList = new ArrayList<Participator>();
		participatorList = participatorDAO.getParticipatorList(participator);
		if (participatorList.size()!= 1) return null;
		return participatorList.get(0);
	}
}
