package com.example.demo.dao.domain;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import com.example.demo.domain.Paper;

@Mapper
public interface PaperMapper{
	
	@Select("SELECT TITLE, PAPERID, CONTACTAUTHOREMAIL FROM PAPER")
	public List<Paper> getPaperList();
	@Insert(
		"INSERT INTO paper(paperid, title, filename, contactauthoremail, abstract) VALUES ((select max(paperid)+1 from paper), #{title}, #{filename}, #{contactauthoremail}, #{abstractval})")
	public void submitPaper(Paper paper);
}
