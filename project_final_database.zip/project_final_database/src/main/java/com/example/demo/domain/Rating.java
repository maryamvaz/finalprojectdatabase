package com.example.demo.domain;

public class Rating{
	private String revemail;
	private String paperid;
	private String techmerit;
	private String readability;
	private String originality;
	private String relavance;
	private String overallrecomm;
	private String commentforauthor;
	private String commentforcommittee;

	
	public Rating(String revemail, String paperid, String techmerit, String readability, String originality, String relavance, String overallrecomm, String commentforauthor, String commentforcommittee){
		this.revemail = revemail;
		this.paperid = paperid;
		this.techmerit = techmerit;
		this.readability = readability;
		this.originality = originality;
		this.relavance = relavance;
		this.overallrecomm = overallrecomm;
		this.commentforauthor = commentforauthor;
		this.commentforcommittee = commentforcommittee;
		
	}

	public String getRevemail(){
		return revemail;
	}

	public void setRevemail(String revemail){
		this.revemail = revemail;
	}
	
	public String getPaperid(){
		return paperid;
	}

	public void setPaperid(String paperid){
		this.paperid = paperid;
	}

	public String getTechmerit(){
		return techmerit;
	}

	public void setTechmerit(String techmerit){
		this.techmerit = techmerit;
	}

	public String getReadability(){
		return readability;
	}

	public void setReadability(String readability){
		this.readability = readability;
	}

	public String getOriginality(){
		return originality;
	}

	public void setOriginality(String originality){
		this.originality = originality;
	}

	public String getRelavance(){
		return relavance;
	}

	public void setRelavance(String relavance){
		this.relavance = relavance;
	}
	
	public String getOverallrecomm(){
		return overallrecomm;
	}
	
	public void setOverallrecomm(String overallrecomm){
		this.overallrecomm = overallrecomm;
	}

	public String getCommentforauthor() {
		return commentforauthor;
	}

	public void setCommentforauthor(String commentforauthor) {
		this.commentforauthor = commentforauthor;
	}

	public String getCommentforcommittee() {
		return commentforcommittee;
	}

	public void setCommentforcommittee(String commentforcommittee) {
		this.commentforcommittee = commentforcommittee;
	}
}
