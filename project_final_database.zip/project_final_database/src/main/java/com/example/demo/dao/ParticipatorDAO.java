package com.example.demo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.domain.ParticipatorMapper;
import com.example.demo.domain.Participator;

@Component
public class ParticipatorDAO{
	@Autowired
	ParticipatorMapper participatorMapper;

	public void registerParticipator(Participator participator){
		participatorMapper.registerParticipator(participator);
	}
	public void registerAuthor(Participator participator){
		participatorMapper.registerAuthor(participator);
	}
	public void registerReviewer(Participator participator){
		participatorMapper.registerReviewer(participator);
	}
	public List<Participator> getParticipatorList(Participator participator){
		List<Participator> participatorList = new ArrayList<Participator>();
		participatorList = participatorMapper.getParticipatorList(participator);
		return participatorList;
	}
	
}
