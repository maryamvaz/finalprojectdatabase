package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.PaperDAO;
import com.example.demo.domain.Paper;

@Component
public class PaperService{
	
	@Autowired
	PaperDAO paperDAO;
	public List<Paper> getPaperList(){
		List<Paper>paperList = new ArrayList<Paper>();
		paperList = paperDAO.getPaperList();
		return paperList;
	}
	public void submitPaper(Paper paper){
		paperDAO.submitPaper(paper);
	}
	
}
